# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ChangePasswordWindow.ui'
#
# Created by: PyQt5 UI code generator 5.12.3
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_ChangePasswordWindow(object):
    def setupUi(self, ChangePasswordWindow):
        ChangePasswordWindow.setObjectName("ChangePasswordWindow")
        ChangePasswordWindow.resize(288, 163)
        font = QtGui.QFont()
        font.setFamily("微軟正黑體")
        font.setPointSize(11)
        ChangePasswordWindow.setFont(font)
        ChangePasswordWindow.setModal(True)
        self.gridLayout = QtWidgets.QGridLayout(ChangePasswordWindow)
        self.gridLayout.setContentsMargins(-1, 10, -1, -1)
        self.gridLayout.setVerticalSpacing(10)
        self.gridLayout.setObjectName("gridLayout")
        self.widget = QtWidgets.QWidget(ChangePasswordWindow)
        self.widget.setObjectName("widget")
        self.gridLayout_2 = QtWidgets.QGridLayout(self.widget)
        self.gridLayout_2.setContentsMargins(25, 25, 25, 15)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.label_2 = QtWidgets.QLabel(self.widget)
        self.label_2.setMinimumSize(QtCore.QSize(85, 0))
        self.label_2.setObjectName("label_2")
        self.gridLayout_2.addWidget(self.label_2, 0, 0, 1, 1)
        self.new_pw = QtWidgets.QLineEdit(self.widget)
        self.new_pw.setMinimumSize(QtCore.QSize(100, 0))
        self.new_pw.setInputMethodHints(QtCore.Qt.ImhHiddenText|QtCore.Qt.ImhNoAutoUppercase|QtCore.Qt.ImhNoPredictiveText|QtCore.Qt.ImhSensitiveData)
        self.new_pw.setInputMask("")
        self.new_pw.setEchoMode(QtWidgets.QLineEdit.Password)
        self.new_pw.setObjectName("new_pw")
        self.gridLayout_2.addWidget(self.new_pw, 0, 1, 1, 1)
        self.label_3 = QtWidgets.QLabel(self.widget)
        self.label_3.setMinimumSize(QtCore.QSize(85, 0))
        self.label_3.setObjectName("label_3")
        self.gridLayout_2.addWidget(self.label_3, 1, 0, 1, 1)
        self.new_pw_chk = QtWidgets.QLineEdit(self.widget)
        self.new_pw_chk.setMinimumSize(QtCore.QSize(100, 0))
        self.new_pw_chk.setInputMethodHints(QtCore.Qt.ImhHiddenText|QtCore.Qt.ImhNoAutoUppercase|QtCore.Qt.ImhNoPredictiveText|QtCore.Qt.ImhSensitiveData)
        self.new_pw_chk.setInputMask("")
        self.new_pw_chk.setEchoMode(QtWidgets.QLineEdit.Password)
        self.new_pw_chk.setObjectName("new_pw_chk")
        self.gridLayout_2.addWidget(self.new_pw_chk, 1, 1, 1, 1)
        self.buttonBox = QtWidgets.QDialogButtonBox(self.widget)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setCenterButtons(True)
        self.buttonBox.setObjectName("buttonBox")
        self.gridLayout_2.addWidget(self.buttonBox, 2, 0, 1, 2)
        self.gridLayout.addWidget(self.widget, 0, 0, 1, 1)

        self.retranslateUi(ChangePasswordWindow)
        self.buttonBox.accepted.connect(ChangePasswordWindow.accept)
        self.buttonBox.rejected.connect(ChangePasswordWindow.reject)
        QtCore.QMetaObject.connectSlotsByName(ChangePasswordWindow)

    def retranslateUi(self, ChangePasswordWindow):
        _translate = QtCore.QCoreApplication.translate
        ChangePasswordWindow.setWindowTitle(_translate("ChangePasswordWindow", "Change Password"))
        self.label_2.setText(_translate("ChangePasswordWindow", "新密碼"))
        self.new_pw.setPlaceholderText(_translate("ChangePasswordWindow", "請輸入密碼"))
        self.label_3.setText(_translate("ChangePasswordWindow", "新密碼確認"))
        self.new_pw_chk.setPlaceholderText(_translate("ChangePasswordWindow", "請再輸入一次密碼"))

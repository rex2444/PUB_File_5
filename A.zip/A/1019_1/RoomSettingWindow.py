# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'RoomSettingWindow.ui'
#
# Created by: PyQt5 UI code generator 5.12.3
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_RoomSettingWindow(object):
    def setupUi(self, RoomSettingWindow):
        RoomSettingWindow.setObjectName("RoomSettingWindow")
        RoomSettingWindow.resize(278, 111)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(RoomSettingWindow.sizePolicy().hasHeightForWidth())
        RoomSettingWindow.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setFamily("微軟正黑體")
        font.setPointSize(11)
        RoomSettingWindow.setFont(font)
        self.gridLayout = QtWidgets.QGridLayout(RoomSettingWindow)
        self.gridLayout.setContentsMargins(-1, 10, -1, 8)
        self.gridLayout.setVerticalSpacing(10)
        self.gridLayout.setObjectName("gridLayout")
        spacerItem = QtWidgets.QSpacerItem(10, 20, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 0, 1, 1, 1)
        self.save_btn = QtWidgets.QPushButton(RoomSettingWindow)
        self.save_btn.setMinimumSize(QtCore.QSize(100, 0))
        font = QtGui.QFont()
        font.setFamily("微軟正黑體")
        font.setPointSize(11)
        font.setBold(False)
        font.setWeight(50)
        self.save_btn.setFont(font)
        self.save_btn.setObjectName("save_btn")
        self.gridLayout.addWidget(self.save_btn, 3, 0, 1, 4, QtCore.Qt.AlignHCenter)
        self.label = QtWidgets.QLabel(RoomSettingWindow)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        spacerItem1 = QtWidgets.QSpacerItem(10, 20, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem1, 1, 1, 1, 1)
        self.label_2 = QtWidgets.QLabel(RoomSettingWindow)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.admin_list = QtWidgets.QLineEdit(RoomSettingWindow)
        self.admin_list.setMinimumSize(QtCore.QSize(100, 0))
        font = QtGui.QFont()
        font.setFamily("Courier New")
        font.setPointSize(10)
        self.admin_list.setFont(font)
        self.admin_list.setText("")
        self.admin_list.setObjectName("admin_list")
        self.gridLayout.addWidget(self.admin_list, 0, 2, 1, 1)
        self.user_list = QtWidgets.QLineEdit(RoomSettingWindow)
        self.user_list.setMinimumSize(QtCore.QSize(100, 0))
        font = QtGui.QFont()
        font.setFamily("Courier New")
        font.setPointSize(10)
        self.user_list.setFont(font)
        self.user_list.setText("")
        self.user_list.setObjectName("user_list")
        self.gridLayout.addWidget(self.user_list, 1, 2, 1, 1)

        self.retranslateUi(RoomSettingWindow)
        QtCore.QMetaObject.connectSlotsByName(RoomSettingWindow)
        RoomSettingWindow.setTabOrder(self.admin_list, self.user_list)
        RoomSettingWindow.setTabOrder(self.user_list, self.save_btn)

    def retranslateUi(self, RoomSettingWindow):
        _translate = QtCore.QCoreApplication.translate
        RoomSettingWindow.setWindowTitle(_translate("RoomSettingWindow", "Room Setting"))
        self.save_btn.setText(_translate("RoomSettingWindow", "Save"))
        self.label.setText(_translate("RoomSettingWindow", "admins"))
        self.label_2.setText(_translate("RoomSettingWindow", "users"))

# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'LoginWindow.ui'
#
# Created by: PyQt5 UI code generator 5.12.3
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_LoginWindow(object):
    def setupUi(self, LoginWindow):
        LoginWindow.setObjectName("LoginWindow")
        LoginWindow.resize(272, 171)
        font = QtGui.QFont()
        font.setFamily("微軟正黑體")
        font.setPointSize(11)
        LoginWindow.setFont(font)
        LoginWindow.setStyleSheet("")
        LoginWindow.setModal(True)
        self.gridLayout = QtWidgets.QGridLayout(LoginWindow)
        self.gridLayout.setContentsMargins(-1, 10, -1, -1)
        self.gridLayout.setVerticalSpacing(10)
        self.gridLayout.setObjectName("gridLayout")
        self.widget = QtWidgets.QWidget(LoginWindow)
        self.widget.setObjectName("widget")
        self.gridLayout_2 = QtWidgets.QGridLayout(self.widget)
        self.gridLayout_2.setContentsMargins(25, 20, 25, 15)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.label = QtWidgets.QLabel(self.widget)
        self.label.setMinimumSize(QtCore.QSize(85, 0))
        self.label.setObjectName("label")
        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 1)
        self.ac = QtWidgets.QLineEdit(self.widget)
        self.ac.setMinimumSize(QtCore.QSize(100, 0))
        self.ac.setObjectName("ac")
        self.gridLayout_2.addWidget(self.ac, 0, 1, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.widget)
        self.label_2.setMinimumSize(QtCore.QSize(85, 0))
        self.label_2.setObjectName("label_2")
        self.gridLayout_2.addWidget(self.label_2, 1, 0, 1, 1)
        self.pw = QtWidgets.QLineEdit(self.widget)
        self.pw.setMinimumSize(QtCore.QSize(100, 0))
        self.pw.setInputMethodHints(QtCore.Qt.ImhHiddenText|QtCore.Qt.ImhNoAutoUppercase|QtCore.Qt.ImhNoPredictiveText|QtCore.Qt.ImhSensitiveData)
        self.pw.setInputMask("")
        self.pw.setEchoMode(QtWidgets.QLineEdit.Password)
        self.pw.setObjectName("pw")
        self.gridLayout_2.addWidget(self.pw, 1, 1, 1, 1)
        self.sav_ac = QtWidgets.QCheckBox(self.widget)
        self.sav_ac.setChecked(True)
        self.sav_ac.setObjectName("sav_ac")
        self.gridLayout_2.addWidget(self.sav_ac, 2, 0, 1, 2, QtCore.Qt.AlignHCenter)
        self.buttonBox = QtWidgets.QDialogButtonBox(self.widget)
        self.buttonBox.setStyleSheet("")
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setCenterButtons(True)
        self.buttonBox.setObjectName("buttonBox")
        self.gridLayout_2.addWidget(self.buttonBox, 3, 0, 1, 2)
        self.gridLayout.addWidget(self.widget, 0, 0, 1, 1)

        self.retranslateUi(LoginWindow)
        self.buttonBox.accepted.connect(LoginWindow.accept)
        self.buttonBox.rejected.connect(LoginWindow.reject)
        QtCore.QMetaObject.connectSlotsByName(LoginWindow)

    def retranslateUi(self, LoginWindow):
        _translate = QtCore.QCoreApplication.translate
        LoginWindow.setWindowTitle(_translate("LoginWindow", "Login"))
        self.label.setText(_translate("LoginWindow", "Username"))
        self.ac.setPlaceholderText(_translate("LoginWindow", "請輸入帳號"))
        self.label_2.setText(_translate("LoginWindow", "Password"))
        self.pw.setPlaceholderText(_translate("LoginWindow", "請輸入密碼"))
        self.sav_ac.setText(_translate("LoginWindow", "記住帳號"))

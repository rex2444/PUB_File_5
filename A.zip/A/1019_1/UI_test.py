# -*- coding: utf-8 -*-
import os
import sys
import shutil
import pickle
import time
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import Qt, QSettings, QVariant, QTimer, QEvent, QRectF
from PyQt5.QtGui import QIcon, QKeySequence, QTextCursor, QFont, QRegExpValidator, QPixmap, QPainter, QPainterPath, \
                        QColor
from PyQt5.QtWidgets import QMainWindow, QDialog, QApplication, QDesktopWidget, QSystemTrayIcon, QMenu, QShortcut, \
                            QFileDialog, QMessageBox, QInputDialog, QLineEdit, QLabel, QGraphicsDropShadowEffect


# 匯入 圖片 資源
import Resources


# 匯入 UI
from MainWindow import Ui_MainWindow
from OptionWindow import Ui_OptionWindow
from LoginWindow import Ui_LoginWindow
from RoomSettingWindow import Ui_RoomSettingWindow
from ChangePasswordWindow import Ui_ChangePasswordWindow

# 解決任務列 ICON 不顯示
import ctypes
ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("myappid")

userinfo_path = u"\\\\lp5-fs\\設計部\\OPTI\\temp\\Melan\\py\\成品\\LCV\\UserFile\\user.info"
room_path = u"\\\\lp5-fs\\設計部\\OPTI\\temp\\Melan\\py\\成品\\LCV\\test\\RoomFile"
file_path = u"\\\\lp5-fs\\設計部\\OPTI\\temp\\Melan\\py\\成品\\LCV\\test\\ImageFile"
online_path = u"\\\\lp5-fs\\設計部\\OPTI\\temp\\Melan\\py\\成品\\LCV\\test\\OnlineFile"

sbox = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
        0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
        0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
        0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
        0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
        0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
        0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
        0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
        0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
        0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
        0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
        0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
        0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
        0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
        0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
        0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16]
sbox_inv = [None] * 256
for i in range(0, len(sbox)):
    sbox_inv[sbox[i]] = i


def encrypt(uncode_text):
    # 加密
    uncode_text_bytes = bytes(uncode_text, encoding='utf-8')
    n = len(uncode_text_bytes)
    encode_text = bytearray(n)
    j=0
    for i in range(0, n):
        encode_text_1 = uncode_text_bytes[i]
        encode_text_2 = sbox[encode_text_1]
        encode_text[j] = encode_text_2
        j = i+1
    encode_text_hex = encode_text.hex()
    return encode_text_hex


def decrypt(code_text_hex):
    # 解密
    code_text = bytes.fromhex(code_text_hex)
    n = len(code_text)
    decode_text_bytes = bytearray(n)

    j = 0
    for i in range(0, n):
        decode_text_1 = code_text[i]
        decode_text_2 = sbox_inv[decode_text_1]
        decode_text_bytes[j] = decode_text_2
        j = i + 1
    decode_text = decode_text_bytes.decode('utf-8')
    return decode_text


class MainWindow(QMainWindow):
    def __init__(self, ac, pw):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.option_window = OptionWindow()
        self.ui.setupUi(self)
        self.moveFlag = False
        self.alertSecs = 1
        self.BgOpacity = -1

        # 從 Login Window 傳進 使用者名稱
        self.username = ac
        # print(pw)

        # 偽裝圖片
        self.block_label = QLabel(self)
        self.block_img = QPixmap("Block.png")
        self.block_label.setPixmap(self.block_img)
        self.block_label.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.block_label.setGeometry(0, 0, 0, 0)
        self.block_label.setVisible(False)

        """設定 Timer"""
        # 系統托盤單下點擊判定用
        self.disambiguateTimer = QTimer(self)
        self.disambiguateTimer.setSingleShot(True)
        self.disambiguateTimer.timeout.connect(self.disambiguateTimerTimeout)
        # 測試三秒後閃爍
        self.testtimer = QTimer(self)
        self.testtimer.setSingleShot(True)
        self.testtimer.timeout.connect(self.window_alert)
        # 更新迴圈
        self.update_text_timer = QTimer(self)
        self.update_text_timer.timeout.connect(self.update_text)
        self.update_online_timer = QTimer(self)
        self.update_online_timer.timeout.connect(self.update_online)
        self.update_online_timer.start(10000)

        self.setup_ui()
        self.set_shortcuts()

        """套用外部設定檔"""
        config_path = 'Config.ini'
        self.config = QSettings(config_path, QSettings.IniFormat)
        if not os.path.isfile(config_path):
            self.save_config()
        self.read_config()

    def send_message(self):
        msg = self.ui.msg_to_send.text()
        if msg != '':
            title = self.windowTitle()
            self.ui.msg_to_send.setText('')
            # self._tray.showMessage(title, msg, QIcon(icon_path))

            # 結尾換行插入
            self.ui.MsgBrowser.append('[' + time.strftime('%H:%M', time.localtime()) + ']' +
                                      '%-6s：'%str(self.username) + msg)
            # 結尾同行插入
            # self.ui.MsgBrowser.insertPlainText(msg)
            # 顯示到最後
            self.ui.MsgBrowser.moveCursor(QTextCursor.End)
            self.ui.MsgBrowser.verticalScrollBar().setValue(self.ui.MsgBrowser.verticalScrollBar().maximum())

            # 送出時上傳
            if self.ui.room_btn.isChecked():
                self.upload_text()

            '''
            測試
            self.showLogText.setText("{0} initializing...".format(time.strftime("%F %T")))
            # self.showLogText.setText("""车道中心线\n车道中心线\n车道中心线""")
            txt = self.ui.MsgBrowser.toPlainText()
            s = txt.split('\n')
            print(s)
            '''

    def update_text(self):
        """更新訊息"""
        room_name = encrypt(self.ui.room_btn.text())
        room_file = room_path + u'\\' + room_name
        # 檢查 server 檔案存在
        if os.path.exists(room_file):
            # 檢查本地檔案存在
            if not os.path.exists(room_name):
                shutil.copyfile(room_file, room_name)
            # 檢查修改時間
            if os.stat(room_file).st_mtime != os.stat(room_name).st_mtime:
                # 目前被提及次數
                t1 = open(room_name, 'r')
                temp_str = decrypt(t1.read())
                mention_times = temp_str.count(u"@" + self.username) + temp_str.count(u"@everyone")
                t1.close()

                # 更新檔案
                shutil.copy2(room_file, room_name)
                t2 = open(room_name, 'r')
                self.ui.MsgBrowser.setHtml(self.new_html(decrypt(t2.read())))

                # 檢查有無新提及
                temp_str = self.ui.MsgBrowser.toHtml()
                new_mention_times = temp_str.count(u"@" + self.username) + temp_str.count(u"@everyone")
                if new_mention_times > mention_times:
                    self._tray.showMessage(self.windowTitle(), "Normal AUTO Completion", QIcon(icon_path))
                t2.close()

                # 顯示到最後, 按鈕提示, 閃爍提示
                self.ui.MsgBrowser.moveCursor(QTextCursor.End)
                self.ui.MsgBrowser.verticalScrollBar().setValue(self.ui.MsgBrowser.verticalScrollBar().maximum())
                self.ui.room_btn.setToolTip("Connected")
                self.window_alert()
        else:
            # 找不到路徑則判斷網路斷線, 停止迴圈
            self.update_text_timer.stop()
            self.ui.room_btn.setText(decrypt(room_name) + "(X)")
            self.ui.room_btn.setChecked(False)
            self.ui.room_btn.setToolTip("Disconnected")

            # 顯示到最後
            self.ui.MsgBrowser.append("\n連線已中斷... (伺服器檔案可能遭刪除)")
            self.ui.MsgBrowser.moveCursor(QTextCursor.End)
            self.ui.MsgBrowser.verticalScrollBar().setValue(self.ui.MsgBrowser.verticalScrollBar().maximum())

            # 變更系統托盤名稱
            self._tray.setToolTip(self.ui.room_btn.text())

    def upload_text(self):
        """上傳訊息"""
        room_name = encrypt(self.ui.room_btn.text())
        room_file = room_path + u'\\' + room_name

        # 以預設字型輸出
        old_html = self.ui.MsgBrowser.toHtml()
        new_html = old_html.replace(self.config.value("FontFamily", 'Courier New'), 'Courier New')
        new_html = new_html.replace('font-size:' + self.config.value("FontSize", 10, type=str) + 'pt',
                                    'font-size:10pt')

        t = open(room_name, 'w')
        t.write(encrypt(new_html))
        t.close()

        # 上傳
        shutil.copy2(room_name, room_file)

    def update_online(self):
        """更新線上人員"""
        if self.ui.room_btn.isChecked():
            room_name = encrypt(self.ui.room_btn.text())
            online_folder_path = online_path + u'\\' + room_name
            # if not os.path.isdir(online_folder_path):
            #     os.mkdir(online_folder_path)
            online_file_path = online_path + u'\\' + room_name + u'\\' + encrypt(self.username)
            t = open(online_file_path, 'w')
            t.write(str(time.time()))
            t.close()

            # 跳過 權限設定檔名 "users"
            online_users_str = "Online:"
            for user in os.listdir(online_folder_path):
                users_path = os.path.join(online_folder_path, user)
                online_time = os.stat(users_path).st_mtime
                if decrypt(user) != "users" and time.time() - float(online_time) < 100:
                    online_users_str += " " + decrypt(user)
            self.ui.CodeVLabel.setToolTip(online_users_str)
        else:
            self.ui.CodeVLabel.setToolTip("Offline")

    def upload_file(self):
        """上傳圖片/檔案"""
        if self.ui.room_btn.isChecked():
            room_name = encrypt(self.ui.room_btn.text())

            # 設定副檔名過濾,注意用雙分號間隔
            local_file_path, file_type = QFileDialog.getOpenFileName(self, "選取檔案", "./",
                                                               "Image Files (*.png *.jpg *.bmp *.ico);;All Files (*)")

            # 檢查有無選擇檔案
            if local_file_path != '':
                base, extension = os.path.splitext(os.path.basename(local_file_path))

                # 複製到 SERVER (原檔名+時間+副檔名)
                new_file_path = file_path + u"\\" + room_name
                if not os.path.isdir(new_file_path):
                    os.mkdir(new_file_path)
                new_file_path = file_path + u"\\" + room_name + u"\\" + encrypt(base) + u"_" + \
                                time.strftime('%Y%m%d-%H%M%S', time.localtime(time.time())) + extension
                shutil.copy2(local_file_path, new_file_path)

                # 自動發出 SERVER 檔案路徑 文字
                self.ui.MsgBrowser.append('[' + time.strftime('%H:%M', time.localtime()) + ']' +
                                          '%-6s：' % str(self.username) + new_file_path)
                # 若在圖片類型選擇 則 同時貼圖 (目前不變更尺寸)
                if file_type.find("Image Files") > -1:
                    self.ui.MsgBrowser.append('<img src="' + new_file_path + '">')
                    # self.ui.MsgBrowser.append('<img src="' + new_file_path + '" width=' + str(int(self.ui.MsgBrowser.width())*0.8) + '>')
                else:
                    pass
                    # self.ui.MsgBrowser.append('[' + time.strftime('%H:%M', time.localtime()) + ']' + '%-6s：'%str(self.username) +
                    #                           '<a href="' + new_file_path + '">' + os.path.basename(new_file_path) + '</a>')

                # 設定格式 (停用)
                # self.config.sync()
                # msg_font = QFont(self.config.value("FontFamily", 'Courier New'), self.config.value("FontSize", 10, type=int))
                # self.ui.MsgBrowser.setCurrentFont(msg_font)

                # 留一空行
                self.ui.MsgBrowser.append('')
                # 顯示到最後
                self.ui.MsgBrowser.moveCursor(QTextCursor.End)
                self.ui.MsgBrowser.verticalScrollBar().setValue(self.ui.MsgBrowser.verticalScrollBar().maximum())

                # 送出時上傳
                if self.ui.room_btn.isChecked():
                    self.upload_text()

    def show_room_setting_window(self):
        """房間權限設定視窗"""
        if self.ui.room_btn.isChecked():
            room_name = encrypt(self.ui.room_btn.text())
            users_path = online_path + u'\\' + room_name + u'\\' + encrypt("users")
            if os.path.exists(users_path):
                t = open(users_path, 'r')
                user_list = decrypt(t.read())
                t.close()
                if user_list.find(self.username) < user_list.find("||"):
                    """開起子視窗"""
                    on_top_state = self.ui.OnTopToggle.isChecked()
                    self.ui.OnTopToggle.setChecked(False)
                    # self.room_setting_window.option_apply = 0
                    ret = RoomSettingWindow(room_name, self.username).exec_()
                    self.ui.OnTopToggle.setChecked(on_top_state)
                else:
                    QMessageBox.critical(self, "Sequence aborted", "You are not admin.", QMessageBox.Ok, QMessageBox.Ok)

    def join_room(self):
        self.update_text_timer.stop()
        if self.ui.room_btn.isChecked():
            # 先取消啟用狀態避免小 BUG
            self.ui.room_btn.setChecked(False)
            room_name = self.ui.room_btn.text().replace("(X)", "")
            if self.ui.room_btn.text() == "New Lens":
                room_name = ""

            room_name, okPressed = QInputDialog.getText(self, "New Lens", "Room name:", QLineEdit.Normal, room_name)
            room_name = encrypt(room_name)
            if okPressed and room_name != '':
                # 刪除本地檔案
                if os.path.exists(room_name):
                    os.remove(room_name)

                # 檢查房間存在, 不存在則創立新檔案
                room_file = room_path + u'\\' + room_name
                users_path = online_path + u'\\' + room_name + u'\\' + encrypt("users")
                if not os.path.exists(room_file):
                    t = open(room_file, 'w')
                    new_str = "Welcome to " + decrypt(room_name) + ". Created by " + self.username
                    t.write(encrypt(new_str))
                    t.close()

                    online_folder_path = online_path + u'\\' + room_name
                    if not os.path.isdir(online_folder_path):
                        os.mkdir(online_folder_path)

                    t2 = open(users_path, 'w')
                    t2.write(encrypt('_' + self.username + '__||__'))
                    t2.close()

                t2 = open(users_path, 'r')
                user_list = decrypt(t2.read())
                t2.close()

                # 檢查房間進入權限
                if user_list.find("_" + self.username + "_") != -1:
                    # 設定按鈕名稱與啟用狀態
                    self.ui.room_btn.setText(decrypt(room_name))
                    self.ui.room_btn.setChecked(True)

                    # 立即更新本地檔案, 並關閉訊息通知再開始更新迴圈
                    self.update_text()
                    self.new_msg_tray.setVisible(False)
                    self.update_text_timer.start(300)
                else:
                    QMessageBox.critical(self, "Sequence aborted", "Permission Denied.", QMessageBox.Ok, QMessageBox.Ok)

                    # 於房間內顯示通知
                    t = open(room_file, 'r')
                    temp_str = decrypt(t.read()) + "<br>" + self.username + " 嘗試加入房間..." + "<br>"
                    t.close()

                    t = open(room_file, 'w')
                    t.write(encrypt(temp_str))
                    t.close()
        else:
            if self.ui.room_btn.text() != "New Lens":
                self.ui.room_btn.setText(self.ui.room_btn.text().replace("(X)", "") + "(X)")
                self.ui.MsgBrowser.append("\n連線已中斷... (使用者操作)")

        # 變更系統托盤名稱
        self._tray.setToolTip(self.ui.room_btn.text())

    def show_option_window(self):
        """個人化設定視窗"""
        on_top_state = self.ui.OnTopToggle.isChecked()
        self.ui.OnTopToggle.setChecked(False)
        '''連結按鈕至'''
        self.option_window.ui.save_btn.clicked.connect(self.save_config)
        self.option_window.option_apply = 0
        ret = self.option_window.exec_()
        if ret == 1:
            self.read_config()
            # 顯示到最後
            self.ui.MsgBrowser.moveCursor(QTextCursor.End)
            self.ui.MsgBrowser.verticalScrollBar().setValue(self.ui.MsgBrowser.verticalScrollBar().maximum())
        self.ui.OnTopToggle.setChecked(on_top_state)

    def show_change_password_window(self):
        ret = ChangePasswordWindow(self.username).exec_()

    def read_config(self):
        self.config.sync()

        """換行"""
        self.option_window.ui.wrap_mode.setCurrentIndex(self.config.value("WrapMode", 0, type=int))
        self.ui.MsgBrowser.setLineWrapMode(self.config.value("WrapMode", True, type=int))

        """背景透明度"""
        self.option_window.ui.BgOpacity.setCurrentIndex(self.config.value("BgOpacity", 1, type=int))
        if self.config.value("BgOpacity", type=int) == 0:
            self.BgOpacity = 0.01
        elif self.config.value("BgOpacity", type=int) == 1:
            self.BgOpacity = 0.05
        elif self.config.value("BgOpacity", type=int) == 2:
            self.BgOpacity = 0.1
        else:
            self.BgOpacity = -1

        # 提醒閃爍時間
        self.option_window.ui.AlertSecs.setCurrentIndex(self.config.value("AlertSecs", 1, type=int))
        self.alertSecs = self.config.value("AlertSecs", 1, type=int)

        """字型"""
        self.option_window.ui.fontComboBox.setCurrentText(self.config.value("FontFamily", 'Courier New'))
        self.option_window.ui.Font_Size.setValue(self.config.value("FontSize", 10, type=int))
        self.ui.MsgBrowser.setHtml(self.new_html())

        # 框架設定
        msg_font = QFont(self.config.value("FontFamily", 'Courier New'), self.config.value("FontSize", 10, type=int))
        self.ui.MsgBrowser.setCurrentFont(msg_font)

        """UI 設定"""
        self.option_window.ui.frameless.setChecked(self.config.value("Frameless", False, type=bool))
        if self.option_window.ui.frameless.isChecked():
            self.setWindowFlags(self.windowFlags() | Qt.FramelessWindowHint)
        else:
            self.setWindowFlags(self.windowFlags() & ~Qt.FramelessWindowHint)
        self.show()

        self.option_window.ui.sav_pos.setChecked(self.config.value("SavePosition", False, type=bool))
        if self.option_window.ui.sav_pos.isChecked():
            self.move(self.config.value("pos", QVariant(self.pos())))
            self.resize(self.config.value("size", QVariant(self.size())))

        self.option_window.ui.sav_opacity.setChecked(self.config.value("SaveOpacity", True, type=bool))
        if self.option_window.ui.sav_opacity.isChecked():
            self.FgOpacity = self.config.value("Opacity", 100, type=int)/100
            self.ui.OpacitySlider.setValue(self.config.value("Opacity", 100, type=int))
            # self.ui.OnTopToggle.setChecked(self.config.value("OnTop", False, type=bool))

        # 偽裝圖片
        if os.path.exists("Block.png"):
            self.option_window.ui.block_window.setChecked(self.config.value("BlockWindow", False, type=bool))
            self.block_img = QPixmap("Block.png")
            self.block_label.setPixmap(self.block_img)
        else:
            self.option_window.ui.block_window.setChecked(False)
        if self.option_window.ui.block_window.isChecked():
            self.block_label.setGeometry(0, 0, self.block_img.width(), self.block_img.height())
            self.resize(self.block_img.width(),self.block_img.height())
        else:
            self.block_label.setGeometry(0, 0, 0, 0)

    def save_config(self):
        self.config.setValue("FontFamily", QVariant(self.option_window.ui.fontComboBox.currentText()))
        self.config.setValue("FontSize", QVariant(self.option_window.ui.Font_Size.value()))
        self.config.setValue("WrapMode", QVariant(self.option_window.ui.wrap_mode.currentIndex()))
        self.config.setValue("BgOpacity", QVariant(self.option_window.ui.BgOpacity.currentIndex()))
        self.config.setValue("AlertSecs", QVariant(self.option_window.ui.AlertSecs.currentIndex()))

        self.config.setValue("Frameless", self.option_window.ui.frameless.isChecked())
        if self.option_window.ui.frameless.isChecked():
            self.setWindowFlags(self.windowFlags() | Qt.FramelessWindowHint)
        else:
            self.setWindowFlags(self.windowFlags() & ~Qt.FramelessWindowHint)
        self.show()

        self.config.setValue("SavePosition", self.option_window.ui.sav_pos.isChecked())
        if self.option_window.ui.sav_pos.isChecked():
            self.config.setValue("pos", QVariant(self.pos()))
            self.config.setValue("size", QVariant(self.size()))

        self.config.setValue("SaveOpacity", self.option_window.ui.sav_opacity.isChecked())
        if self.option_window.ui.sav_opacity.isChecked():
            self.config.setValue("Opacity", QVariant(self.ui.OpacitySlider.value()))
            # self.config.setValue("OnTop", self.ui.OnTopToggle.isChecked())

        # 偽裝圖片
        self.config.setValue("BlockWindow", self.option_window.ui.block_window.isChecked())

    def new_html(self, old_html=None):
        """按本地設定轉換文本格式"""
        self.config.sync()
        # 舊文本
        old_font = self.ui.MsgBrowser.currentFont().family()
        old_size = self.ui.MsgBrowser.currentFont().pointSize()
        if old_html is None:
            old_html = self.ui.MsgBrowser.toHtml()
        new_html = old_html.replace('Courier New', self.config.value("FontFamily", 'Courier New'))
        new_html = new_html.replace(old_font, self.config.value("FontFamily", 'Courier New'))
        new_html = new_html.replace('font-size:10pt',
                                    'font-size:' + self.config.value("FontSize", 10, type=str) + 'pt')
        new_html = new_html.replace('font-size:' + str(old_size) + 'pt',
                                    'font-size:' + self.config.value("FontSize", 10, type=str) + 'pt')
        return new_html
        # self.ui.MsgBrowser.setHtml(new_html)

    def changeOpacity(self, value):
        """視窗透明度"""
        self.FgOpacity = value/100
        self.setWindowOpacity(value/100)

    def changeOnTopToggle(self, state):
        """最上層顯示"""
        if state == Qt.Checked:
            # self.ui.OnTopToggle.setText('On Top')
            self.ui.OnTopToggle.setToolTip('Always On Top: enabled')
            self.setWindowFlags(self.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)
            self.show()
            # QMessageBox.information(self, 'checkbox', 'true')

        elif state == Qt.Unchecked:
            # self.ui.OnTopToggle.setText('Normal')
            self.ui.OnTopToggle.setToolTip('Always On Top: disabled')
            self.setWindowFlags(self.windowFlags() & ~QtCore.Qt.WindowStaysOnTopHint)
            self.show()
            # QMessageBox.information(self, 'checkbox', 'false')

    def setup_ui(self):
        self.set_tray()
        self.set_buttons()

        # 無邊框
        self.setWindowFlag(Qt.FramelessWindowHint)
        # # 背景透明
        # #self.setAttribute(Qt.WA_TranslucentBackground)
        # # 圓角
        # radius = 5
        # self.ui.centralwidget.setStyleSheet(format(
        #         """
        #         background:rgb(255, 255, 255);
        #         border-top-left-radius:{0}px;
        #         border-bottom-left-radius:{0}px;
        #         border-top-right-radius:{0}px;
        #         border-bottom-right-radius:{0}px;
        #         """.format(radius)
        #     ))
        #

    def set_buttons(self):
        """設定按紐"""
        # [-], [+] 按鈕 ICON
        self.ui.folded_btn.setIcon(QIcon(":icon/folded.png"))
        self.ui.folded_btn.clicked.connect(self.show_room_setting_window)
        self.ui.unfolded_btn.setIcon(QIcon(":icon/unfolded.png"))
        self.ui.unfolded_btn.clicked.connect(self.upload_file)

        # 原 Clear Text 按鈕
        self.ui.room_btn.clicked.connect(self.join_room)
        self.ui.room_btn.setText('New Lens')
        self.ui.room_btn.setToolTip("Disconnected")
        #self.ui.room_btn.setText('Clear Text')
        #self.ui.room_btn.clicked.connect(self.send_message)
        self.ui.preference_btn.clicked.connect(self.show_option_window)
        self.ui.pw_btn.clicked.connect(self.show_change_password_window)

        self.ui.OnTopToggle.stateChanged.connect(self.changeOnTopToggle)
        self.ui.OpacitySlider.valueChanged.connect(self.changeOpacity)

    def set_shortcuts(self):
        """鍵盤快捷建設定"""
        QShortcut(QKeySequence(self.tr("Esc")), self.ui.msg_to_send, self.showMinimized)
        QShortcut(QKeySequence(self.tr("Return")), self.ui.msg_to_send, self.send_message)
        QShortcut(QKeySequence(self.tr("Enter")), self.ui.msg_to_send, self.send_message)

    def set_tray(self):
        self._tray = QSystemTrayIcon(self)
        if self._tray.isSystemTrayAvailable():
            self._tray.setIcon(QIcon(icon_path))
            self._tray.setToolTip(self.windowTitle())
        else:
            self._tray = None
        tray_menu = QMenu(self)

        self._tray.activated.connect(self.onTrayIconActivated)
        self._tray.setContextMenu(tray_menu)
        self._tray.messageClicked.connect(self.tag_msg_click)    # 設定點擊訊息時動作
        """顯示/隱藏"""
        action_show = tray_menu.addAction(QIcon(icon_path), "顯示/隱藏")
        action_show.triggered.connect(lambda: self.hide() if self.isVisible() else self.show())

        """測試"""
        action_alert = tray_menu.addAction("3秒後閃爍測試")
        action_alert.triggered.connect(lambda: self.testtimer.start(3000))
        action_test = tray_menu.addAction("新訊息測試")
        action_test.triggered.connect(lambda: self.new_msg_tray.setVisible(True))
        action_test2 = tray_menu.addAction("TAG 測試")
        action_test2.triggered.connect(lambda: self._tray.showMessage(self.windowTitle(), "Normal AUTO Completion", QIcon(icon_path)))

        """分隔線"""
        tray_menu.addSeparator()
        """結束"""
        action_quit = tray_menu.addAction(QIcon(':icon\\Exit.ico'), "退出")
        action_quit.triggered.connect(self.quit)

        self._tray.show()

        self.new_msg_tray = QSystemTrayIcon(self)
        if self.new_msg_tray.isSystemTrayAvailable():
            self.new_msg_tray.setIcon(QIcon(':icon\\NewMsg.ico'))
            self.new_msg_tray.setToolTip(self.windowTitle())
        else:
            self.new_msg_tray = None
        self.new_msg_tray.activated.connect(self.new_msg_icon)

    def onTrayIconActivated(self, reason):
        # 雙擊系統托盤 顯示/隱藏 主視窗
        # print("onTrayIconActivated:", reason)
        if reason == QSystemTrayIcon.Trigger:
            self.disambiguateTimer.start(QApplication.doubleClickInterval())
        elif reason == QSystemTrayIcon.DoubleClick:
            self.disambiguateTimer.stop()
            if self.isVisible():
                self.hide()
            else:
                self.show()
                self.activateWindow()

    def disambiguateTimerTimeout(self):
        # 判定單擊
        print("Tray icon single clicked")

    def new_msg_icon(self):
        # 系統托盤的新訊息提醒 點擊顯示主視窗後隱藏
        if self.isMinimized():
            self.showNormal()
        if not self.isVisible():
            self.show()
        self.activateWindow()
        self.new_msg_tray.setVisible(False)

    def tag_msg_click(self):
        if self.isMinimized():
            self.showNormal()
        if not self.isVisible():
            self.show()
        on_top_state = self.ui.OnTopToggle.isChecked()
        if not on_top_state:
            self.ui.OnTopToggle.setChecked(True)
            self.ui.OnTopToggle.setChecked(on_top_state)
        # self.activateWindow()

    def window_alert(self):
        """視窗提醒"""
        if not self.isActiveWindow():
            # 視窗閃爍
            if self.alertSecs != 0:
                QtWidgets.QApplication.alert(self, self.alertSecs*1000)
            # 系統托盤提示 (鈴鐺樣式)
            self.new_msg_tray.setVisible(True)

    def changeEvent(self, e):
        """視窗啟用/非啟用事件"""
        # 啟用視窗時 隱藏系統托盤的新訊息提醒
        if e.type() == QEvent.ActivationChange and self.isActiveWindow:
            self.new_msg_tray.setVisible(False)

    """移進和移出"""
    def enterEvent(self, a0: QtCore.QEvent) -> None:
        self.setWindowOpacity(self.FgOpacity)
        self.block_label.setVisible(False)
        self.new_msg_tray.setVisible(False)

    def leaveEvent(self, a0: QtCore.QEvent) -> None:
        self.block_label.setVisible(True)
        if not self.BgOpacity == -1:
            self.setWindowOpacity(self.BgOpacity)

    """覆寫滑鼠事件"""
    def mousePressEvent(self, event):
        if 1: # event.button() == Qt.LeftButton:
            self.moveFlag = True
            self.movePosition = event.globalPos() - self.pos()
            #self.setCursor(QCursor(Qt.OpenHandCursor))
            event.accept()
        # elif event.button() == Qt.RightButton:
        #    pass #self.popMenu.exec_(self.button.mapToGlobal(point))

    def mouseMoveEvent(self, event):
        if self.moveFlag:
            self.move(event.globalPos() - self.movePosition)
            event.accept()

    def mouseReleaseEvent(self, event):
        self.moveFlag = False
        # self.setCursor(Qt.CrossCursor)
        # self.setCursor(QCursor(Qt.ArrowCursor))

    def quit(self):
        result = QtWidgets.QMessageBox.question(self, self.windowTitle(),
                                                "確認要結束嗎?",
                                                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        if result == QtWidgets.QMessageBox.Yes:
            # QApplication.closeAllWindows()
            # 讓 tray icon 消失的替代方案
            self._tray.setVisible(False)
            self.new_msg_tray.setVisible(False)
            # self._tray = None
            self.save_config()
            self.close()
            app.quit()

    """覆寫視窗關閉事件"""
    def closeEvent(self, event):
        self.hide()
        event.ignore()


class OptionWindow(QDialog):
    def __init__(self):
        super(OptionWindow, self).__init__()
        self.option_apply = 0
        self.ui = Ui_OptionWindow()
        self.ui.setupUi(self)
        self.moveFlag = False

        # 最上層顯示
        self.setWindowFlags(self.windowFlags() | Qt.FramelessWindowHint)

        # 背景透明
        self.setAttribute(Qt.WA_TranslucentBackground, True)

        # 外框陰影
        effect = QGraphicsDropShadowEffect(self)
        effect.setBlurRadius(10)
        effect.setOffset(1, 1)
        effect.setColor(Qt.black)
        self.setGraphicsEffect(effect)

        self.ui.block_window.stateChanged.connect(self.checkBlockImage)
        self.ui.save_btn.clicked.connect(self.apply)

    def paintEvent(self, event):
        # 圓角
        pat2 = QPainter(self)
        pat2.setRenderHint(pat2.Antialiasing)  # 反鋸齒
        pat2.setBrush(Qt.white)
        pat2.setPen(Qt.transparent)
        rect = self.rect()
        rect.setLeft(13)
        rect.setTop(13)
        rect.setWidth(rect.width() - 13)
        rect.setHeight(rect.height() - 13)
        pat2.drawRoundedRect(rect, 6, 6)

    def checkBlockImage(self):
        if self.ui.block_window.isChecked():
            if not os.path.exists("Block.png"):
                QtWidgets.QMessageBox.warning(self, "Preference", "找不到 Block.png，請放至程式相同目錄下。",
                                              QtWidgets.QMessageBox.Ok)
                self.ui.block_window.setCheckState(False)

    def apply(self):
        self.option_apply = 1
        self.close()

    """覆寫滑鼠事件"""
    def mousePressEvent(self, event):
        if 1: # event.button() == Qt.LeftButton:
            self.moveFlag = True
            self.movePosition = event.globalPos() - self.pos()
            #self.setCursor(QCursor(Qt.OpenHandCursor))
            event.accept()
        # elif event.button() == Qt.RightButton:
        #    pass #self.popMenu.exec_(self.button.mapToGlobal(point))

    def mouseMoveEvent(self, event):
        if self.moveFlag:
            self.move(event.globalPos() - self.movePosition)
            event.accept()

    def mouseReleaseEvent(self, event):
        self.moveFlag = False

    def closeEvent(self, event):
        #QApplication.closeAllWindows()
        self.finish_dialog()
        event.accept()

    @QtCore.pyqtSlot(int)
    def finish_dialog(self):
        self.setResult(self.option_apply)


class RoomSettingWindow(QDialog):
    def __init__(self, room_name, username):
        super(RoomSettingWindow, self).__init__()
        self.admin_user = ''
        self.ui = Ui_RoomSettingWindow()
        self.ui.setupUi(self)
        self.moveFlag = False

        # 最上層顯示
        # self.setWindowFlags(self.windowFlags() | Qt.FramelessWindowHint)

        self.ui.save_btn.clicked.connect(self.apply)

        self.username = username
        self.users_path = online_path + u'\\' + room_name + u'\\' + encrypt("users")
        # 轉換符號
        if os.path.exists(self.users_path):
            t = open(self.users_path, 'r')
            admin_user_list = decrypt(t.read())
            admin_list = admin_user_list[0:admin_user_list.find("_||_")]
            self.ui.admin_list.setText(admin_list.replace("__!__", " ").replace("__@__", ",").replace("_", " ").strip())

            user_list = admin_user_list[admin_user_list.find("_||_")+4:]
            self.ui.user_list.setText(user_list.replace("__!__", " ").replace("__@__", ",").replace("_", " ").strip())

            t.close()

    def apply(self):
        t = open(self.users_path, 'w')
        if self.ui.admin_list.text().find(self.username) == -1:
            self.ui.admin_list.setText(self.username + ", " + self.ui.admin_list.text())
        # 轉換符號
        admin_user_list = " " + self.ui.admin_list.text() + u'_||_' + self.ui.user_list.text() + " "
        admin_user_list = admin_user_list.replace(" ", "__!__").replace(",", "__@__").replace(" ", "_")
        t.write(encrypt(admin_user_list))
        t.close()

        self.close()

    """覆寫滑鼠事件"""
    def mousePressEvent(self, event):
        if 1: # event.button() == Qt.LeftButton:
            self.moveFlag = True
            self.movePosition = event.globalPos() - self.pos()
            #self.setCursor(QCursor(Qt.OpenHandCursor))
            event.accept()
        # elif event.button() == Qt.RightButton:
        #    pass #self.popMenu.exec_(self.button.mapToGlobal(point))

    def mouseMoveEvent(self, event):
        if self.moveFlag:
            self.move(event.globalPos() - self.movePosition)
            event.accept()

    def mouseReleaseEvent(self, event):
        self.moveFlag = False

    def closeEvent(self, event):
        # QApplication.closeAllWindows()
        # self.finish_dialog()
        event.accept()


class ChangePasswordWindow(QDialog):
    def __init__(self, username):
        super(ChangePasswordWindow, self).__init__()
        self.admin_user = ''
        self.ui = Ui_ChangePasswordWindow()
        self.ui.setupUi(self)
        self.moveFlag = False
        self.username = username

        # 最上層顯示
        self.setWindowFlags(self.windowFlags() | Qt.FramelessWindowHint)

        # 背景透明
        self.setAttribute(Qt.WA_TranslucentBackground, True)

        # 外框陰影
        effect = QGraphicsDropShadowEffect(self)
        effect.setBlurRadius(10)
        effect.setOffset(1, 1)
        effect.setColor(Qt.black)
        self.setGraphicsEffect(effect)

        # 密碼遮罩
        my_regex = QtCore.QRegExp("^[A-Za-z0-9]+$")
        my_validator = QRegExpValidator(my_regex, self.ui.new_pw)
        self.ui.new_pw.setValidator(my_validator)
        self.ui.new_pw_chk.setValidator(my_validator)
        self.ui.buttonBox.accepted.connect(self.change_password)

    def paintEvent(self, event):
        # 圓角
        pat2 = QPainter(self)
        pat2.setRenderHint(pat2.Antialiasing)  # 反鋸齒
        pat2.setBrush(Qt.white)
        pat2.setPen(Qt.transparent)
        rect = self.rect()
        rect.setLeft(13)
        rect.setTop(13)
        rect.setWidth(rect.width() - 13)
        rect.setHeight(rect.height() - 13)
        pat2.drawRoundedRect(rect, 6, 6)

    def change_password(self):
        if self.ui.new_pw.text() == self.ui.new_pw_chk.text():
            new_pw = self.ui.new_pw.text()
            if len(new_pw) > 0:
                with open(userinfo_path, 'rb') as userfile:
                    exist_userinfo = pickle.load(userfile)
                    exist_userinfo[self.username] = new_pw
                with open(userinfo_path, 'wb') as userfile:
                    pickle.dump(exist_userinfo, userfile)
                QtWidgets.QMessageBox.information(self, "Change Password", "密碼修改成功", QtWidgets.QMessageBox.Ok)
            else:
                QtWidgets.QMessageBox.critical(self, "Change Password", "密碼不可為空", QtWidgets.QMessageBox.Ok)
        else:
            QtWidgets.QMessageBox.critical(self, "Change Password", "兩次輸入密碼不相符", QtWidgets.QMessageBox.Ok)

    """覆寫滑鼠事件"""
    def mousePressEvent(self, event):
        if 1: # event.button() == Qt.LeftButton:
            self.moveFlag = True
            self.movePosition = event.globalPos() - self.pos()
            #self.setCursor(QCursor(Qt.OpenHandCursor))
            event.accept()
        # elif event.button() == Qt.RightButton:
        #    pass #self.popMenu.exec_(self.button.mapToGlobal(point))

    def mouseMoveEvent(self, event):
        if self.moveFlag:
            self.move(event.globalPos() - self.movePosition)
            event.accept()

    def mouseReleaseEvent(self, event):
        self.moveFlag = False

    def closeEvent(self, event):
        #QApplication.closeAllWindows()
        event.accept()


class LoginWindow(QDialog):
    def __init__(self):
        super(LoginWindow, self).__init__()
        self.ui = Ui_LoginWindow()
        self.ui.setupUi(self)
        self.moveFlag = False
        self.login_ac = None

        # 最上層顯示
        self.setWindowFlags(self.windowFlags() | Qt.FramelessWindowHint)

        # 背景透明
        self.setAttribute(Qt.WA_TranslucentBackground, True)

        # 外框陰影
        effect = QGraphicsDropShadowEffect(self)
        effect.setBlurRadius(14)
        effect.setOffset(1, 1)
        effect.setColor(Qt.black)
        self.setGraphicsEffect(effect)
        # 文字陰影
        effect2 = QGraphicsDropShadowEffect(self)
        effect2.setBlurRadius(4)
        effect2.setOffset(2, 2)
        effect2.setColor(Qt.lightGray)
        self.ui.widget.setGraphicsEffect(effect2)

        # 密碼遮罩
        my_regex = QtCore.QRegExp("^[A-Za-z0-9]+$")
        my_validator = QRegExpValidator(my_regex, self.ui.pw)
        self.ui.pw.setValidator(my_validator)
        self.ui.buttonBox.accepted.connect(self.login)

        """套用外部設定檔"""
        config_path = 'LoginConfig.ini'
        self.config = QSettings(config_path, QSettings.IniFormat)
        self.ui.sav_ac.setChecked(self.config.value("Save_Account", True, type=bool))
        if os.path.isfile(config_path):
            self.ui.ac.setText(self.config.value("Account", "", type=str))
            self.ui.pw.setFocus()

    def paintEvent(self, event):
        # 圓角
        pat2 = QPainter(self)
        pat2.setRenderHint(pat2.Antialiasing)  # 反鋸齒
        pat2.setBrush(Qt.white)
        pat2.setPen(Qt.transparent)
        rect = self.rect()
        rect.setLeft(13)
        rect.setTop(13)
        rect.setWidth(rect.width() - 13)
        rect.setHeight(rect.height() - 13)
        pat2.drawRoundedRect(rect, 6, 6)

    def login(self):
        try:
            with open(userinfo_path, 'rb') as userfile:
                userinfo = pickle.load(userfile)
        except FileNotFoundError:
            with open(userinfo_path, 'wb') as userfile:
                userinfo = {'rex': 'rex',
                            'alex': '0000',
                            'andy': '0000',
                            'dar': '0000',
                            'dennis': '0000',
                            'han': '0000',
                            'jason': '0000',
                            'jeremy': '0000',
                            'kc': '0000',
                            'melan': '0000',
                            'peter': '0000',
                            'ray': '0000',
                            'taylor': '0000',
                            }
                pickle.dump(userinfo, userfile)
                userfile.close()
        if self.ui.ac.text() in userinfo:
            if self.ui.pw.text() == userinfo[self.ui.ac.text()]:
                self.config.setValue("Save_Account", self.ui.sav_ac.isChecked())
                if self.ui.sav_ac.isChecked():
                    self.config.setValue("Account", QVariant(self.ui.ac.text()))
                else:
                    self.config.remove("Account")
                # self.close()
                # 傳入使用者名稱、密碼, 啟動主視窗
                MainWindow(self.ui.ac.text(), self.ui.pw.text())
            else:
                QtWidgets.QMessageBox.critical(self, self.windowTitle(), "登入失敗，密碼不正確。", QtWidgets.QMessageBox.Ok)
        else:
            QtWidgets.QMessageBox.critical(self, self.windowTitle(), "登入失敗，無此使用者。", QtWidgets.QMessageBox.Ok)

    """覆寫滑鼠事件"""
    def mousePressEvent(self, event):
        if 1: # event.button() == Qt.LeftButton:
            self.moveFlag = True
            self.movePosition = event.globalPos() - self.pos()
            #self.setCursor(QCursor(Qt.OpenHandCursor))
            event.accept()
        # elif event.button() == Qt.RightButton:
        #    pass #self.popMenu.exec_(self.button.mapToGlobal(point))

    def mouseMoveEvent(self, event):
        if self.moveFlag:
            self.move(event.globalPos() - self.movePosition)
            event.accept()

    def mouseReleaseEvent(self, event):
        self.moveFlag = False

    def closeEvent(self, event):
        # QApplication.closeAllWindows()
        # self.finish_dialog()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    icon_path = ":icon\\CODEV.ico"
    app.setWindowIcon(QIcon(icon_path))

    window = LoginWindow()
    window.show()

    '''
        #解決 Win 7 程式開啟較久後渲染問題
        #方法一 OpenGL
        QCoreApplication.setAttribute(Qt.AA_UseDesktopOpenGL, True)
        QGuiApplication.setAttribute(Qt.AA_UseDesktopOpenGL, True)
        QApplication.setAttribute(Qt.AA_UseSoftwareOpenGL, True)
        #方法二 在一個論壇當中，也找到了一個這樣的回答：
        #QCoreApplication.setAttribute(Qt.AA_UseOpenGLES, True)
        
        最后最小化和关闭可以设置两个按钮，通过点击按钮来触发
        @pyqtSlot()
        def on_pushButton_clicked(self):
            """
            关闭窗口
            """
            self.close()
        
        @pyqtSlot()
        def on_pushButton_2_clicked(self):
            """
            最小化窗口
            """
            self.showMinimized()
    '''
    sys.exit(app.exec_())
